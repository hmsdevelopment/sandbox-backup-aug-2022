/**
 * @author Midware
 * @Website www.midware.net
 * @Developer Sergio Tijerino
 * @contact contact@midware.net
 */

//Includes the body and header styles for all forms
export var GLOBAL_URL = "https://1309901.app.netsuite.com/core/media/media.nl?id=106583&c=1309901&h=bf5df8d56aa36d439a81&_xt=.css";

//Builder Portal styles
export var BUILDER_PORTAL = {

    //Styles for the forms
    FORM_URL : "https://1309901.app.netsuite.com/core/media/media.nl?id=106582&c=1309901&h=95409e5a14563b0d3861&_xt=.css",
    
    //Styles for the menus, where you choose an option
    MENU_URL : "https://1309901.app.netsuite.com/core/media/media.nl?id=106585&c=1309901&h=efbb0d4c3f2f500bcca1&_xt=.css",

    //Styles only used for the login
    LOGIN_URL : "https://1309901.app.netsuite.com/core/media/media.nl?id=106584&c=1309901&h=b35d40f39cf422c328f9&_xt=.css",

    //Used for the Create New Listing and Modify New Listing forms, made by other people
    CREATE_MODIFY_LISTING : {
        CREATE_MODIFY_LISTING_URL : "https://1309901.app.netsuite.com/core/media/media.nl?id=106814&c=1309901&h=55cb74685ed8ddfccf47&_xt=.css"
    },

    //Specific styles for some pages
    SUBMIT_FORMS : {
        GLOBAL_URL : "https://1309901.app.netsuite.com/core/media/media.nl?id=107033&c=1309901&h=46bed5f7c3971bff9c78&_xt=.css",
        SUBMIT_A_CLOSING_URL : "https://1309901.app.netsuite.com/core/media/media.nl?id=107034&c=1309901&h=624eca02f24b606217cf&_xt=.css",
        SUBMIT_A_SALE : "https://1309901.app.netsuite.com/core/media/media.nl?id=107035&c=1309901&h=30a2c2bdaba825c0f46e&_xt=.css"
    }
}

//Ghost Listing Styles
export var GHOST_LISTING = {
    GLOBAL_URL : "https://1309901.app.netsuite.com/core/media/media.nl?id=107140&c=1309901&h=c88f52949a89e843ed6e&_xt=.css",
    MANAGEMENT_PORTAL_URL : "https://1309901.app.netsuite.com/core/media/media.nl?id=107036&c=1309901&h=e54807c67694c87c4257&_xt=.css",
    GET_HTML_URL : "https://1309901.app.netsuite.com/core/media/media.nl?id=107344&c=1309901&h=b6f3676aa8a5a1d5edf4&_xt=.css", //Method in LeaveAsIsView that shares CSS with other views
    RELOCATE_URL : "https://1309901.app.netsuite.com/core/media/media.nl?id=107347&c=1309901&h=40afc796ebbda2337fbc&_xt=.css"
}

